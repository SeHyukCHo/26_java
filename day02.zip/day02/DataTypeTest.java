package day02;

public class DataTypeTest {

	public static void main(String[] args) {
		// 1. 기본형 변수 선언
		boolean isTrue;
		int age;
		double height, weight;
		
		// 2. 변수 초기화
		isTrue = false;
		age = 23;
		height = 175;
		weight = 67;
		
		
		
		// 2. 레퍼런스형 - 3개 (배열, 클래스, 인터페이스)
		String name = "조세혁";
		//name = "조세혁";
		String s = new String("조세혁");
		
		
		DataTypeTest ddt = new DataTypeTest();
		// 주소 addr
		String addr = "자양동 84-31";
		
		// 3. 변수 값 출력하기
		System.out.println(isTrue);
		System.out.println("나이:"+age);
		System.out.println("키:"+height);
		System.out.println("몸무게:"+weight);
		System.out.println("나이:"+name);
		System.out.println("주소:"+addr);
		
		
		
		

	}

}
