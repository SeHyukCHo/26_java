package day02;

public class Hello0310 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("안녕하세요 저는 조세혁 입니다");
		System.out.println("대전대학교 재학중인 2학년");
		System.out.println("정보보안학과에 다니고 있습니다");
		System.out.println("자바를 이용해 각종 사이트를 만들어 보겠습니다");
				

	}

}
